from django.db import models

# Just a requirement
